// All database READS used by pages live here (TODO 29). Pages never talk to Prisma directly.
//
// Every function is cached ("use cache") so the pages stay fast and can still be prepared
// ahead of time, EXCEPT searchContent (its input is whatever a visitor types, so caching it
// would fill the cache with one entry per search; it only runs inside the dynamic /search part)
// and getMySocialLikes (it is about ONE logged-in person, so it must never go into the shared cache).
// When something is saved to the database later (Phase 2), the code that saves it must also
// call updateTag("<tag>") so the pages show the new data. The tags are:
//   "communities"  -> the list of communities, their rules and member counts
//   "posts"        -> post lists, vote totals and comment counts (Home, Popular, c/<slug>, post)
//   "comments"     -> the comment thread under one post
//   "modlog"       -> the public moderation log (every moderator action must update it)
//   "ads"          -> the pool of running ads (code that approves, pauses or ends an ad must update it)
// A new comment changes BOTH the thread and the count on the post: update "comments" and "posts".
// A vote on a post updates "posts"; a vote on a comment updates "comments".
// These caches are shared by everybody, so they hold NO personal data. The highlighted arrow
// (the logged-in person's own vote) is loaded separately: src/app/vote/my-votes.ts and
// src/components/MyVotesProvider.tsx. The same goes for the filled heart on a Social post
// (the person's own like): getMySocialLikes below, called by the page for each request.
//
// Return plain data only (text, numbers, lists), never Prisma objects or Dates.
import { cacheLife, cacheTag } from "next/cache";
import { socialPostTag } from "@/lib/social-cache-tags";
import { connection } from "next/server";
import { prisma } from "@/lib/prisma";
import { getLocale, t } from "@/i18n";
import { adsConfig, rankingConfig, socialLimits } from "@/config/site";
import { nowMs } from "@/lib/now";
import { rankTrendingTags, type TrendingTag } from "@/lib/social-discover-rules";
import { rankPopularDetailed, type RankItem } from "@/lib/ranking";
import { collapsePlainReposts } from "@/lib/social-fair-rank-rules";
import { socialAuthorShown } from "@/lib/social-visibility";
import { followingAuthorIds, MAX_FOLLOWING_IDS } from "@/lib/social-following";
import { afterCursorWhere, comparePageItems, cursorToText, cutPage, parseCursor } from "@/lib/social-paging";
import { bookmarkAfterWhere, bookmarkCursorToText, cutBookmarkPage, parseBookmarkCursor } from "@/lib/social-bookmark-rules";
import { NEW_POSTS_CAP } from "@/lib/social-new-posts";
import { rankPeople, rankTags, SOCIAL_SEARCH_LIST_SIZE } from "@/lib/social-search";
import { AdStatus, AuditAction, AuditTarget, ContentStatus, UserStatus, type Prisma } from "../../generated/prisma/client";

export type CommunitySummary = {
  slug: string;
  name: string;
  description: string;
  members: number; // real number of memberships
  rules: { title: string; text: string }[]; // only the active rules, in order
};

/** Every community that is not archived, oldest first. */
export async function getCommunities(): Promise<CommunitySummary[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("communities");

  const rows = await prisma.community.findMany({
    where: { archivedAt: null },
    orderBy: { id: "asc" },
    include: {
      rules: {
        where: { archivedAt: null },
        orderBy: { position: "asc" },
        select: { title: true, text: true },
      },
      _count: { select: { memberships: true } },
    },
  });

  return rows.map((c) => ({
    slug: c.slug,
    name: c.name,
    description: c.description,
    members: c._count.memberships,
    rules: c.rules,
  }));
}

export async function getCommunity(slug: string): Promise<CommunitySummary | undefined> {
  const all = await getCommunities(); // already cached: no extra database read
  return all.find((c) => c.slug === slug);
}

// ---------------------------------------------------------------------------------
// Posts and comments
// ---------------------------------------------------------------------------------

/** Set when a post or comment is hidden for review (it is never deleted). */
// removed: true = a second person confirmed the removal (TODO 38/39); the text is still blank, the rule and the reason stay visible.
export type HiddenInfo = { rule: string; note: string; removed?: true };

export type PostSummary = {
  id: number;
  createdAtMs: number;
  community: string; // community slug
  author: string; // username
  time: string; // "12 minutes ago" in the active language
  title: string; // empty while the post is hidden
  body: string; // empty while the post is hidden
  votes: number; // up minus down
  comments: number;
  hidden?: HiddenInfo;
  deleted?: true; // the author erased it: text blank, author hidden (only the post page shows this)
  edited?: true; // the author changed the text after posting
  newVoice?: true; // Popular only: this post holds a reserved "new voice" place (TODO 37); the card shows a label
};

export type CommentNode = {
  id: number;
  author: string;
  time: string;
  text: string; // empty while the comment is hidden
  votes: number;
  hidden?: HiddenInfo;
  deleted?: true; // the author erased it: text blank, author hidden (only the post page shows this)
  edited?: true; // the author changed the text after posting
  replies?: CommentNode[];
};

/** A date as "12 minutes ago" / "yesterday" in the active language. Older than 30 days: a date. */
export function timeAgo(date: Date): string {
  const locale = getLocale();
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: "auto" });
  const seconds = Math.round((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return rtf.format(0, "second");
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return rtf.format(-minutes, "minute");
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return rtf.format(-hours, "hour");
  const days = Math.floor(hours / 24);
  if (days < 30) return rtf.format(-days, "day");
  return new Intl.DateTimeFormat(locale, { dateStyle: "medium", timeZone: "UTC" }).format(date);
}

function ruleLabel(rule: { position: number; title: string } | null): string {
  return rule ? `Rule ${rule.position}: ${rule.title}` : "";
}

const postSelect = {
  id: true,
  title: true,
  body: true,
  status: true,
  statusNote: true,
  createdAt: true,
  editedAt: true,
  deletedAt: true,
  community: { select: { slug: true } },
  author: { select: { username: true } },
  statusRule: { select: { position: true, title: true } },
  _count: { select: { comments: { where: { status: { not: ContentStatus.REMOVED } } } } },
} satisfies Prisma.PostSelect;

type PostRow = Prisma.PostGetPayload<{ select: typeof postSelect }>;

const commentSelect = {
  id: true,
  parentId: true,
  body: true,
  status: true,
  statusNote: true,
  createdAt: true,
  editedAt: true,
  deletedAt: true,
  author: { select: { username: true } },
  statusRule: { select: { position: true, title: true } },
} satisfies Prisma.CommentSelect;

type CommentRow = Prisma.CommentGetPayload<{ select: typeof commentSelect }>;

type VoteInfo = { votes: number };

/** Vote total (up minus down) for each post id. */
async function postVoteInfo(ids: number[]): Promise<Map<number, VoteInfo>> {
  if (ids.length === 0) return new Map();
  const sums = await prisma.postVote.groupBy({
    by: ["postId"],
    where: { postId: { in: ids } },
    _sum: { value: true },
  });
  return new Map(ids.map((id) => [id, { votes: sums.find((s) => s.postId === id)?._sum.value ?? 0 }]));
}

/** Vote total (up minus down) for each comment of one post. */
async function commentVoteInfo(postId: number): Promise<Map<number, VoteInfo>> {
  const sums = await prisma.commentVote.groupBy({
    by: ["commentId"],
    where: { comment: { postId } },
    _sum: { value: true },
  });
  return new Map(sums.map((s) => [s.commentId, { votes: s._sum.value ?? 0 }]));
}

// Hidden and erased content is blanked here, so its text never reaches a page. An erased
// (deleted) item also loses its author name: nobody can see who wrote it any more.
function toPost(row: PostRow, vote: VoteInfo | undefined): PostSummary {
  const deleted = row.deletedAt !== null;
  const removed = !deleted && row.status === ContentStatus.REMOVED;
  const hidden = !deleted && (removed || row.status === ContentStatus.HIDDEN_PENDING_REVIEW);
  const blank = deleted || hidden;
  return {
    id: row.id,
    createdAtMs: row.createdAt.getTime(),
    community: row.community.slug,
    author: deleted ? "" : row.author.username,
    time: timeAgo(row.createdAt),
    title: blank ? "" : row.title,
    body: blank ? "" : row.body,
    votes: vote?.votes ?? 0,
    comments: row._count.comments,
    ...(deleted ? { deleted: true as const } : {}),
    ...(row.editedAt !== null && !blank ? { edited: true as const } : {}),
    ...(hidden ? { hidden: { rule: ruleLabel(row.statusRule), note: row.statusNote ?? "", ...(removed ? { removed: true as const } : {}) } } : {}),
  };
}

function toComment(row: CommentRow, vote: VoteInfo | undefined): CommentNode {
  const deleted = row.deletedAt !== null;
  const removed = !deleted && row.status === ContentStatus.REMOVED;
  const hidden = !deleted && (removed || row.status === ContentStatus.HIDDEN_PENDING_REVIEW);
  const blank = deleted || hidden;
  return {
    id: row.id,
    author: deleted ? "" : row.author.username,
    time: timeAgo(row.createdAt),
    text: blank ? "" : row.body,
    votes: vote?.votes ?? 0,
    ...(deleted ? { deleted: true as const } : {}),
    ...(row.editedAt !== null && !blank ? { edited: true as const } : {}),
    ...(hidden ? { hidden: { rule: ruleLabel(row.statusRule), note: row.statusNote ?? "", ...(removed ? { removed: true as const } : {}) } } : {}),
  };
}

async function loadPosts(where: Prisma.PostWhereInput, take?: number): Promise<PostSummary[]> {
  const rows = await prisma.post.findMany({
    // Erased posts are not listed anywhere; only their own /post/<id> page shows the notice.
    where: { status: { not: ContentStatus.REMOVED }, deletedAt: null, ...where },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }], // newest first
    ...(take ? { take } : {}),
    select: postSelect,
  });
  const info = await postVoteInfo(rows.map((r) => r.id));
  return rows.map((r) => toPost(r, info.get(r.id)));
}

/** Home: every post that is not removed (hidden ones show a notice), newest first. */
export async function getPosts(): Promise<PostSummary[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("posts");
  return loadPosts({});
}


// ---------------------------------------------------------------------------------
// Combined Home Feed: Community Posts + Social Posts
// ---------------------------------------------------------------------------------

export type SocialPostSummary = {
  id: number;
  author: string;
  displayName: string | null;
  body: string;
  /** Address of the post's picture ("/api/social/media/<file>", login only), or null (patch-social-images). */
  image: string | null;
  time: string;
  createdAtMs: number;
  likes: number;
  reposts: number;
  replies: number;
  /** Running total of views (SOCIAL_TODO B5). */
  views: number;
  /** Usernames saved as mentioned in the text (accounts that exist and may be shown): only these are links (SOCIAL_TODO 6). */
  mentions: string[];
  edited?: true;
  /** When the text was last changed (SOCIAL_TODO item 6). Absent = never edited. */
  editedAtMs?: number;
  /** How many earlier versions are saved = how many edits were made since the edit history exists (SOCIAL_TODO item 6). */
  editCount?: number;
};

/**
 * A repost in a Social feed (SOCIAL_TODO 16): `post` is the ORIGINAL post, `reposter` is who reposted it, `quote` is
 * their own text (null = a plain repost) and `createdAtMs` / `time` are the moment of the repost, so it sorts into the
 * feed by when it was reposted.
 */
export type SocialRepostItem = {
  kind: "repost";
  repostId: number;
  createdAtMs: number;
  time: string;
  reposter: string;
  reposterName: string | null;
  quote: string | null;
  post: SocialPostSummary;
  /** Plain reposts of the same post merged into this one on this page (SOCIAL_TODO B10). Absent = none. */
  alsoCount?: number;
};

export type SocialFeedItem =
  | { kind: "post"; createdAtMs: number; post: SocialPostSummary }
  | SocialRepostItem;

export type HomeFeedItem =
  | { kind: "community"; createdAtMs: number; post: PostSummary }
  | { kind: "social"; createdAtMs: number; post: SocialPostSummary }
  | SocialRepostItem;

const socialPostSelect = {
  id: true,
  body: true,
  mediaUrl: true,
  viewCount: true,
  createdAt: true,
  editedAt: true,
  author: {
    select: {
      username: true,
      displayName: true,
    },
  },
  _count: {
    select: {
      likes: true,
      reposts: true,
      edits: true, // saved earlier versions (SOCIAL_TODO item 6)
      replies: { where: { status: ContentStatus.VISIBLE, deletedAt: null } },
    },
  },
  // SOCIAL_TODO 6: who is mentioned (only accounts that may be shown)
  mentions: {
    where: { user: socialAuthorShown },
    select: { user: { select: { username: true } } },
  },
} satisfies Prisma.SocialPostSelect;

// Which Social posts may be shown in a feed: visible, not deleted, and written by an account whose posts may be
// shown (rules in src/lib/social-visibility.ts). Used by the Home feed and the /social feed, so both always agree.
const socialFeedWhere = {
  status: ContentStatus.VISIBLE,
  deletedAt: null,
  author: socialAuthorShown,
} satisfies Prisma.SocialPostWhereInput;

type SocialRow = Prisma.SocialPostGetPayload<{ select: typeof socialPostSelect }>;

function toSocialSummary(row: SocialRow): SocialPostSummary {
  return {
    id: row.id,
    author: row.author.username,
    displayName: row.author.displayName,
    body: row.body,
    image: row.mediaUrl,
    time: timeAgo(row.createdAt),
    createdAtMs: row.createdAt.getTime(),
    likes: row._count.likes,
    reposts: row._count.reposts,
    replies: row._count.replies,
    views: row.viewCount,
    mentions: row.mentions.map((mention) => mention.user.username),
    editCount: row._count.edits,
    ...(row.editedAt !== null ? { edited: true as const, editedAtMs: row.editedAt.getTime() } : {}),
  };
}

// Reposts that may be shown in a feed: the person who reposted AND the original post both follow the same rules as any
// Social post (visible, not deleted, account shown), so a repost disappears with its original and comes back with it.
const socialRepostWhere = {
  user: socialAuthorShown,
  socialPost: socialFeedWhere,
} satisfies Prisma.SocialRepostWhereInput;

const socialRepostSelect = {
  id: true,
  quoteText: true,
  createdAt: true,
  user: { select: { username: true, displayName: true } },
  socialPost: { select: socialPostSelect },
} satisfies Prisma.SocialRepostSelect;

type SocialRepostRow = Prisma.SocialRepostGetPayload<{ select: typeof socialRepostSelect }>;

function toRepostItem(row: SocialRepostRow): SocialRepostItem {
  return {
    kind: "repost",
    repostId: row.id,
    createdAtMs: row.createdAt.getTime(),
    time: timeAgo(row.createdAt),
    reposter: row.user.username,
    reposterName: row.user.displayName,
    quote: row.quoteText,
    post: toSocialSummary(row.socialPost),
  };
}

const SOCIAL_FEED_SIZE = 50;

/** One page of a Social feed: the items, and the cursor of the next page (null = last page). See social-paging.ts. */
export type SocialFeedPage = { items: SocialFeedItem[]; next: string | null };

/** Newest first, cut to one page. `items` may hold up to SOCIAL_FEED_SIZE + 1 of each table; the extra one tells there is a next page. */
function toFeedPage(items: SocialFeedItem[]): SocialFeedPage {
  const keyed = items.map((item) => ({
    item,
    createdAtMs: item.createdAtMs,
    rank: (item.kind === "repost" ? 1 : 0) as 0 | 1,
    id: item.kind === "repost" ? item.repostId : item.post.id,
  }));
  keyed.sort(comparePageItems);
  const { items: kept, next } = cutPage(keyed, SOCIAL_FEED_SIZE);
  return { items: collapsePlainReposts(kept.map((entry) => entry.item)), next: next ? cursorToText(next) : null };
}

/**
 * The Social feed page (/social, SOCIAL_TODO 11): Social posts only, newest first (never by popularity).
 * ONLY for logged-in people (PROJECT.md 8j point 11): the page must not call this for a visitor.
 * Cached for a few minutes and shared by everybody; "which of these did I like" is loaded separately
 * (getMySocialLikes). Whoever saves, hides or removes a Social post must call updateTag("social-posts").
 */
export async function getSocialFeed(before: string | null = null): Promise<SocialFeedPage> {
  "use cache";
  cacheLife("minutes");
  cacheTag("social-posts");

  const cursor = parseCursor(before); // `before` is a cursor from the URL (the page passes it on in its clean form)

  // Posts and reposts (SOCIAL_TODO 16) together, newest first. A post and its own repost can both appear: they are
  // two different moments.
  const [rows, repostRows] = await Promise.all([
    prisma.socialPost.findMany({
      where: { AND: [socialFeedWhere, afterCursorWhere(cursor, 0)] },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: SOCIAL_FEED_SIZE + 1,
      select: socialPostSelect,
    }),
    prisma.socialRepost.findMany({
      where: { AND: [socialRepostWhere, afterCursorWhere(cursor, 1)] },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: SOCIAL_FEED_SIZE + 1,
      select: socialRepostSelect,
    }),
  ]);

  const items: SocialFeedItem[] = [
    ...rows.map((row): SocialFeedItem => ({ kind: "post", createdAtMs: row.createdAt.getTime(), post: toSocialSummary(row) })),
    ...repostRows.map(toRepostItem),
  ];
  return toFeedPage(items);
}

/**
 * The quote reposts of ONE Social post, newest first (shown under "Quotes" on /social/<id>, SOCIAL_TODO 16).
 * Plain reposts have no text and are not listed. Same visibility rules as the feeds; the page has already checked that
 * the original may be shown. ONLY for logged-in people (PROJECT.md 8j point 11). Cached like the feed.
 */
export async function getSocialQuotes(socialPostId: number): Promise<SocialRepostItem[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("social-posts");

  const rows = await prisma.socialRepost.findMany({
    where: { ...socialRepostWhere, socialPostId, quoteText: { not: null } },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: SOCIAL_FEED_SIZE,
    select: socialRepostSelect,
  });
  return rows.map(toRepostItem);
}

/**
 * One Social post for its own page (/social/<id>, SOCIAL_TODO 14), or null when it does not exist or may not be shown
 * (hidden, removed, deleted, or written by an account whose posts are not shown: the same `socialFeedWhere` as the feeds).
 * ONLY for logged-in people (PROJECT.md 8j point 11): the page must not call this for a visitor.
 * Cached like the feed (tag "social-posts"); the person's own like is loaded separately (getMySocialLikes).
 */
export async function getSocialPost(id: number): Promise<SocialPostSummary | null> {
  "use cache";
  cacheLife("minutes");
  cacheTag("social-posts", socialPostTag(id)); // a like or a reply on THIS post refreshes only this page (social-cache-tags.ts)

  const row = await prisma.socialPost.findFirst({
    where: { ...socialFeedWhere, id },
    select: socialPostSelect,
  });
  return row ? toSocialSummary(row) : null;
}

/**
 * Home: combine the newest Community and Social posts without mixing their data models.
 * Community posts are open to everybody. Social posts are only for people who are logged in
 * (PROJECT.md 8j point 11), so the page passes `includeSocial` = whether somebody is logged in; without it
 * the Social posts are not even read from the database. The two answers are cached separately, and neither
 * holds anything personal.
 */
export async function getHomeFeed(includeSocial: boolean): Promise<HomeFeedItem[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("posts", "social-posts");

  const [communityPosts, socialRows, repostRows] = await Promise.all([
    loadPosts({}, 50),
    includeSocial
      ? prisma.socialPost.findMany({
          where: socialFeedWhere,
          orderBy: [{ createdAt: "desc" }, { id: "desc" }],
          take: SOCIAL_FEED_SIZE,
          select: socialPostSelect,
        })
      : Promise.resolve<SocialRow[]>([]),
    includeSocial
      ? prisma.socialRepost.findMany({
          where: socialRepostWhere,
          orderBy: [{ createdAt: "desc" }, { id: "desc" }],
          take: SOCIAL_FEED_SIZE,
          select: socialRepostSelect,
        })
      : Promise.resolve<SocialRepostRow[]>([]),
  ]);

  const communityItems: HomeFeedItem[] = communityPosts.map((post) => ({
    kind: "community",
    createdAtMs: post.createdAtMs,
    post,
  }));

  const socialItems: HomeFeedItem[] = socialRows.map((row) => ({
    kind: "social",
    createdAtMs: row.createdAt.getTime(),
    post: toSocialSummary(row),
  }));

  const repostItems: HomeFeedItem[] = repostRows.map(toRepostItem);

  // At the same moment: a Social post, then a repost, then a Community post; then the higher id first.
  const kindRank = { social: 0, repost: 1, community: 2 } as const;
  const idOf = (item: HomeFeedItem) => (item.kind === "repost" ? item.repostId : item.post.id);

  const merged = [...communityItems, ...socialItems, ...repostItems]
    .sort((a, b) => {
      const difference = b.createdAtMs - a.createdAtMs;
      if (difference !== 0) return difference;
      if (a.kind !== b.kind) return kindRank[a.kind] - kindRank[b.kind];
      return idOf(b) - idOf(a);
    })
    .slice(0, 50);
  return collapsePlainReposts(merged); // SOCIAL_TODO B10
}

/**
 * The Following feed (/social/following, SOCIAL_TODO 17): Social posts AND reposts / quotes by the people THIS person
 * follows and by the person themselves, newest first (never by popularity). Same visibility rules as the other feeds
 * (`socialFeedWhere`, `socialRepostWhere`: visible, not deleted, accounts shown).
 * ONLY for logged-in people (PROJECT.md 8j point 11). NOT cached on purpose: the answer belongs to one viewer, and the
 * shared caches must hold no personal data. `following` is how many people the viewer follows (the page uses it to say
 * "you follow nobody yet" instead of "nothing here").
 */
export async function getFollowingFeed(
  viewerId: string,
  before: string | null = null,
): Promise<{ following: number; items: SocialFeedItem[]; next: string | null }> {
  const cursor = parseCursor(before);
  const followed = await prisma.follow.findMany({
    where: { followerId: viewerId },
    select: { followingId: true },
    take: MAX_FOLLOWING_IDS,
  });
  const authorIds = followingAuthorIds(viewerId, followed.map((row) => row.followingId));

  const [rows, repostRows] = await Promise.all([
    prisma.socialPost.findMany({
      where: { AND: [socialFeedWhere, { authorId: { in: authorIds } }, afterCursorWhere(cursor, 0)] },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: SOCIAL_FEED_SIZE + 1,
      select: socialPostSelect,
    }),
    prisma.socialRepost.findMany({
      where: { AND: [socialRepostWhere, { userId: { in: authorIds } }, afterCursorWhere(cursor, 1)] },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: SOCIAL_FEED_SIZE + 1,
      select: socialRepostSelect,
    }),
  ]);

  const items: SocialFeedItem[] = [
    ...rows.map((row): SocialFeedItem => ({ kind: "post", createdAtMs: row.createdAt.getTime(), post: toSocialSummary(row) })),
    ...repostRows.map(toRepostItem),
  ];
  return { following: followed.length, ...toFeedPage(items) };
}

const MAX_SOCIAL_LIKE_IDS = 200; // a page never shows more Social posts than this

/**
 * Which of these Social posts has THIS person liked? (SOCIAL_TODO 9)
 * Not cached on purpose: the answer belongs to one viewer, and the shared caches
 * (getHomeFeed and the others) must hold no personal data (see the note at the top of this file).
 * Only call it from a page that already runs per request (the Home page calls `connection()`).
 * Nobody logged in, or no posts: the answer is an empty list and the database is not asked.
 * If the database fails, the page still opens (hearts show as not liked) and the error is logged,
 * the same as getMyVotes.
 */
export async function getMySocialLikes(
  userId: string | null | undefined,
  socialPostIds: number[],
): Promise<number[]> {
  if (!userId) return [];
  const ids = [...new Set(socialPostIds.filter((id) => Number.isInteger(id) && id >= 1))].slice(
    0,
    MAX_SOCIAL_LIKE_IDS,
  );
  if (ids.length === 0) return [];

  try {
    const rows = await prisma.socialPostLike.findMany({
      where: { userId, socialPostId: { in: ids } },
      select: { socialPostId: true },
    });
    return rows.map((row) => row.socialPostId);
  } catch (error) {
    console.error("getMySocialLikes failed:", error);
    return [];
  }
}

/**
 * Which of these Social posts has THIS person reposted (plain or quote)? (SOCIAL_TODO 16)
 * Same rules as getMySocialLikes: not cached (the answer belongs to one viewer), nobody logged in or no posts = an
 * empty answer without asking the database, and a database error is logged while the page still opens (every
 * button shows "not reposted").
 */
export async function getMySocialReposts(
  userId: string | null | undefined,
  socialPostIds: number[],
): Promise<number[]> {
  if (!userId) return [];
  const ids = [...new Set(socialPostIds.filter((id) => Number.isInteger(id) && id >= 1))].slice(
    0,
    MAX_SOCIAL_LIKE_IDS,
  );
  if (ids.length === 0) return [];

  try {
    const rows = await prisma.socialRepost.findMany({
      where: { userId, socialPostId: { in: ids } },
      select: { socialPostId: true },
    });
    return rows.map((row) => row.socialPostId);
  } catch (error) {
    console.error("getMySocialReposts failed:", error);
    return [];
  }
}

const MAX_FOLLOW_NAMES = 200; // a page never shows more Social posts than this

/**
 * Which of these authors does THIS person follow? (SOCIAL_TODO 15)
 * Same rules as getMySocialLikes: not cached (the answer belongs to one viewer), nobody logged in or no names = an
 * empty answer without asking the database, and a database error is logged while the page still opens (every
 * button shows "Follow"). Takes usernames (what a post card has) and returns the usernames that are followed.
 */
export async function getMyFollowing(
  userId: string | null | undefined,
  usernames: string[],
): Promise<string[]> {
  if (!userId) return [];
  const names = [...new Set(usernames.filter((name) => typeof name === "string" && name.length > 0))].slice(
    0,
    MAX_FOLLOW_NAMES,
  );
  if (names.length === 0) return [];

  try {
    const rows = await prisma.follow.findMany({
      where: { followerId: userId, following: { username: { in: names } } },
      select: { following: { select: { username: true } } },
    });
    return rows.map((row) => row.following.username);
  } catch (error) {
    console.error("getMyFollowing failed:", error);
    return [];
  }
}

// What the fair ranking (src/lib/ranking.ts) needs to know about each post: its author's id, how old the
// author's account is and how many visible posts the author has. Nothing here is shown on a page.
const rankSelect = {
  ...postSelect,
  authorId: true,
  author: {
    select: {
      username: true,
      createdAt: true,
      _count: { select: { posts: { where: { status: ContentStatus.VISIBLE, deletedAt: null } } } },
    },
  },
} satisfies Prisma.PostSelect;

/**
 * Popular (TODO 37): no hidden posts; ordered by the fair ranking in src/lib/ranking.ts (votes with
 * diminishing returns and age, one account cannot fill the page, a fixed share of places for new voices).
 * Every visible post is in the list; ranking only changes the order. Cached for a few minutes like the other lists.
 */
export async function getPopularPosts(): Promise<PostSummary[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("posts");
  const rows = await prisma.post.findMany({
    where: { status: ContentStatus.VISIBLE, deletedAt: null },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    select: rankSelect,
  });
  const info = await postVoteInfo(rows.map((r) => r.id));

  const items: RankItem[] = rows.map((r) => ({
    id: r.id,
    authorKey: r.authorId,
    createdAtMs: r.createdAt.getTime(),
    votes: info.get(r.id)?.votes ?? 0,
    authorCreatedAtMs: r.author.createdAt.getTime(),
    authorPosts: r.author._count.posts,
  }));
  const { ids: order, rising } = rankPopularDetailed(items, Date.now(), rankingConfig);

  const byId = new Map(
    rows.map((r) => [r.id, { ...toPost(r, info.get(r.id)), ...(rising.has(r.id) ? { newVoice: true as const } : {}) }]),
  );
  return order.flatMap((id) => {
    const post = byId.get(id);
    return post ? [post] : [];
  });
}

export async function getPostsByCommunity(slug: string): Promise<PostSummary[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("posts");
  return loadPosts({ community: { slug } });
}

export async function getPost(id: number): Promise<PostSummary | null> {
  "use cache";
  cacheLife("minutes");
  cacheTag("posts");
  const row = await prisma.post.findFirst({
    where: { id },
    select: postSelect,
  });
  if (!row) return null;
  const info = await postVoteInfo([row.id]);
  return toPost(row, info.get(row.id));
}

/** Ids of every post that exists, so Next.js can prepare each /post/<id> page in advance. */
export async function getPostIds(): Promise<number[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("posts");
  const rows = await prisma.post.findMany({
    orderBy: { id: "asc" },
    select: { id: true },
  });
  return rows.map((r) => r.id);
}

/**
 * The comment thread under one post: top-level comments, each with its replies (any depth),
 * oldest first. Hidden and removed comments stay in the thread as a notice with the rule and the reason
 * (their text is blank, their replies stay under them).
 */
export async function getComments(postId: number): Promise<CommentNode[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("comments");
  const rows = await prisma.comment.findMany({
    where: { postId },
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    select: commentSelect,
  });
  const info = await commentVoteInfo(postId);

  const nodes = new Map<number, CommentNode>();
  for (const r of rows) nodes.set(r.id, toComment(r, info.get(r.id)));

  const roots: CommentNode[] = [];
  for (const r of rows) {
    const node = nodes.get(r.id)!;
    const parent = r.parentId === null ? undefined : nodes.get(r.parentId);
    if (parent) (parent.replies ??= []).push(node);
    else roots.push(node);
  }
  return roots;
}

/**
 * Search (Phase 1: plain text match). Order is newest first, NOT popularity (fairness
 * principle). Hidden posts are left out, the same as on the Popular page.
 * Not cached on purpose (see the note at the top of this file).
 */
export async function searchContent(
  query: string,
): Promise<{ communities: CommunitySummary[]; posts: PostSummary[] }> {
  const q = query.trim().toLowerCase();
  if (!q) return { communities: [], posts: [] };
  // Not cached, and "x minutes ago" reads the clock: tell Next.js this runs per request.
  await connection();
  const has = (s: string) => s.toLowerCase().includes(q);

  const all = await getCommunities();
  const rows = await prisma.post.findMany({
    where: {
      status: ContentStatus.VISIBLE,
      deletedAt: null,
      OR: [
        { title: { contains: q } },
        { body: { contains: q } },
        { author: { username: { contains: q } } },
      ],
    },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    select: postSelect,
  });
  const info = await postVoteInfo(rows.map((r) => r.id));

  return {
    communities: all.filter((c) => has(c.name) || has(c.slug) || has(c.description)),
    posts: rows.map((r) => toPost(r, info.get(r.id))),
  };
}

// ---------------------------------------------------------------------------------
// Public moderation log
// ---------------------------------------------------------------------------------

export type ModActionKind = "hidden" | "restored" | "removed" | "appealUpheld" | "appealDenied";

export type ModLogItem = {
  id: number;
  time: string;
  moderator: string; // username
  action: ModActionKind;
  target: "post" | "comment";
  community: string; // slug
  subject: string; // "by maya_r" while the content still exists, otherwise empty
  rule: string; // "Rule 2: Be respectful to others", empty when no rule was recorded
  reason: string;
  postId?: number; // set only when the post can still be opened (adds a link)
};

// Only these audit-log actions are public. Other actions (roles, suspensions ...) are not listed here.
const modActionKinds: Record<string, ModActionKind> = {
  [AuditAction.CONTENT_HIDDEN]: "hidden",
  [AuditAction.CONTENT_RESTORED]: "restored",
  [AuditAction.CONTENT_REMOVED]: "removed",
  [AuditAction.APPEAL_ACCEPTED]: "appealUpheld",
  [AuditAction.APPEAL_REJECTED]: "appealDenied",
};

// Audit rows keep the target id as text. Only plain whole numbers can point to a post or comment.
function numericIds(ids: string[]): number[] {
  return ids.filter((id) => /^\d{1,9}$/.test(id)).map(Number);
}

/** The 100 newest moderator actions on posts and comments, newest first. */
export async function getModLog(): Promise<ModLogItem[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("modlog");

  const rows = await prisma.auditLog.findMany({
    where: {
      action: { in: Object.keys(modActionKinds) as AuditAction[] },
      targetType: { in: [AuditTarget.POST, AuditTarget.COMMENT] },
      communityId: { not: null },
    },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: 100,
    select: {
      id: true,
      createdAt: true,
      action: true,
      targetType: true,
      targetId: true,
      reason: true,
      actor: { select: { username: true } },
      community: { select: { slug: true } },
      rule: { select: { position: true, title: true } },
    },
  });

  const postIds = numericIds(rows.filter((r) => r.targetType === AuditTarget.POST).map((r) => r.targetId));
  const commentIds = numericIds(rows.filter((r) => r.targetType === AuditTarget.COMMENT).map((r) => r.targetId));
  const [posts, comments] = await Promise.all([
    prisma.post.findMany({
      where: { id: { in: postIds } },
      select: { id: true, status: true, author: { select: { username: true, status: true } } },
    }),
    prisma.comment.findMany({
      where: { id: { in: commentIds } },
      select: {
        id: true,
        postId: true,
        author: { select: { username: true, status: true } },
        post: { select: { status: true } },
      },
    }),
  ]);
  const postById = new Map(posts.map((p) => [p.id, p]));
  const commentById = new Map(comments.map((c) => [c.id, c]));

  return rows.map((r) => {
    const isPost = r.targetType === AuditTarget.POST;
    const numeric = numericIds([r.targetId])[0];
    const post = isPost && numeric !== undefined ? postById.get(numeric) : undefined;
    const comment = !isPost && numeric !== undefined ? commentById.get(numeric) : undefined;
    // An erased person's name is never shown (PROJECT.md 8c point 6): the rule and the reason stay, the name does not.
    const writer = post?.author ?? comment?.author;
    const author = writer && writer.status !== UserStatus.DELETED ? writer.username : undefined;
    // A removed post still opens: the page shows the notice with the rule and the reason (TODO 39).
    const openableId = post ? post.id : comment ? comment.postId : undefined;
    return {
      id: r.id,
      time: timeAgo(r.createdAt),
      moderator: r.actor.username,
      action: modActionKinds[r.action],
      target: isPost ? "post" : "comment",
      community: r.community?.slug ?? "",
      subject: author ? t("post.by", { author }) : "",
      rule: ruleLabel(r.rule),
      reason: r.reason ?? "",
      ...(openableId !== undefined ? { postId: openableId } : {}),
    };
  });
}

// ---------------------------------------------------------------- Ads (TODO 44, Session 2)

/** What the browser needs to show one ad. No advertiser data, and the destination link stays on the server. */
// format / imageUrl / videoUrl (Session 3b): imageUrl is the picture of an IMAGE ad, or the poster of a VIDEO ad.
// They are always OUR OWN addresses (/api/ad/media/...).
export type AdPoolItem = {
  id: number;
  title: string;
  body: string;
  host: string;
  format: "TEXT" | "IMAGE" | "VIDEO";
  imageUrl: string | null; videoUrl: string | null;
};

/**
 * The candidate ads for one slot (and one community page, if any): ACTIVE ads inside their dates,
 * either for every page or for exactly this community. Fair rotation: ads with the FEWEST impressions
 * in the last `rotation.windowDays` days come first, with some randomness, and `rotation.poolSize`
 * of them are returned. The visitor's browser then picks one it has not shown lately (AdBox.tsx).
 * Shared by everybody and cached for a short time, so it holds no personal data.
 */
export async function getAdPool(slot: "SIDEBAR" | "FEED" | "SOCIAL_FEED" | "HEADER", communitySlug: string | null): Promise<AdPoolItem[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("ads");

  const now = new Date();
  const forThisPage: Prisma.AdCampaignWhereInput = communitySlug
    ? { OR: [{ communityId: null }, { community: { slug: communitySlug } }] }
    : { communityId: null };
  const ads = await prisma.adCampaign.findMany({
    where: {
      status: AdStatus.ACTIVE,
      slot,
      AND: [
        { OR: [{ startDate: null }, { startDate: { lte: now } }] },
        { OR: [{ endDate: null }, { endDate: { gte: now } }] },
        forThisPage,
      ],
    },
    select: { id: true, title: true, body: true, destinationUrl: true, format: true, imageUrl: true, videoUrl: true },
  });
  if (ads.length === 0) return [];

  const since = new Date(
    Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - adsConfig.rotation.windowDays),
  );
  const sums = await prisma.adDailyStat.groupBy({
    by: ["adId"],
    where: { adId: { in: ads.map((a) => a.id) }, date: { gte: since } },
    _sum: { impressions: true },
  });
  const shown = new Map(sums.map((r) => [r.adId, r._sum.impressions ?? 0]));

  const ranked = ads
    .map((ad) => ({ ad, shown: shown.get(ad.id) ?? 0, tie: Math.random() }))
    .sort((a, b) => a.shown - b.shown || a.tie - b.tie);

  // Take the least-shown ads (3x the pool size), shuffle them, keep `poolSize`.
  const size = adsConfig.rotation.poolSize;
  const candidates = ranked.slice(0, size * 3).map((r) => r.ad);
  for (let i = candidates.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
  }

  return candidates.slice(0, size).map((ad) => {
    let host = "";
    try {
      host = new URL(ad.destinationUrl).hostname.replace(/^www\./, "");
    } catch {
      /* the submit form only accepts https links; an unreadable one just shows no host */
    }
    return { id: ad.id, title: ad.title, body: ad.body, host, format: ad.format, imageUrl: ad.imageUrl, videoUrl: ad.videoUrl };
  });
}

// ---- Social profile (SOCIAL_TODO 2, patch-social-profile). Same visibility rules as the feeds. ONLY for logged-in
// people (PROJECT.md 8j point 11). Not cached: they are read per request and the pages hold the viewer's own state.

/** Replies, likes, followers and following lists show at most this many (the newest). Paging for them comes later. */
export const socialProfileListSize = 100;

export type SocialProfile = {
  id: string;
  username: string;
  displayName: string | null;
  bio: string | null;
  joinedIso: string;
  posts: number;
  followers: number;
  following: number;
};

/** The profile of an account whose posts may be shown (socialAuthorShown), or null (unknown, deleted, deletion pending). */
export async function getSocialProfile(username: string): Promise<SocialProfile | null> {
  const user = await prisma.user.findFirst({
    where: { AND: [{ username }, socialAuthorShown] },
    select: { id: true, username: true, displayName: true, bio: true, createdAt: true },
  });
  if (!user) return null;
  const [posts, followers, following] = await Promise.all([
    prisma.socialPost.count({ where: { AND: [socialFeedWhere, { authorId: user.id }] } }),
    prisma.follow.count({ where: { followingId: user.id, follower: socialAuthorShown } }),
    prisma.follow.count({ where: { followerId: user.id, following: socialAuthorShown } }),
  ]);
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    bio: user.bio,
    joinedIso: user.createdAt.toISOString(),
    posts,
    followers,
    following,
  };
}

/**
 * Trending hashtags (SOCIAL_TODO B7): hashtags of visible Social posts (author ACTIVE) made in the last
 * `socialLimits.discover.trendingWindowHours` hours, ranked by how many DIFFERENT people used them (social-discover-rules.ts).
 * Shared by everybody and cached for a few minutes (it holds no personal data); a post saved, hidden or removed calls
 * updateTag("social-posts"). Block and Mute are NOT applied: it is a count over everybody, never a list of people.
 */
export async function getSocialTrendingTags(): Promise<TrendingTag[]> {
  "use cache";
  cacheLife("minutes");
  cacheTag("social-posts");

  const config = socialLimits.discover;
  const since = new Date(nowMs() - config.trendingWindowHours * 3_600_000);
  const rows = await prisma.socialPostTag.findMany({
    where: { socialPost: { status: ContentStatus.VISIBLE, deletedAt: null, createdAt: { gte: since }, author: { status: UserStatus.ACTIVE, deletedAt: null } } },
    orderBy: { createdAt: "desc" },
    take: config.trendingScanLimit,
    select: { tag: true, socialPost: { select: { authorId: true, createdAt: true } } },
  });
  return rankTrendingTags(
    rows.map((row) => ({ tag: row.tag, authorId: row.socialPost.authorId, createdAtMs: row.socialPost.createdAt.getTime() })),
    { minPeople: config.trendingMinPeople, size: config.trendingSize },
  );
}

/** The Posts tab: the person's Social posts AND reposts, newest first, paged like the feeds (social-paging.ts). */
export async function getSocialProfileFeed(profileId: string, before: string | null = null): Promise<SocialFeedPage> {
  const cursor = parseCursor(before);
  const [rows, repostRows] = await Promise.all([
    prisma.socialPost.findMany({
      where: { AND: [socialFeedWhere, { authorId: profileId }, afterCursorWhere(cursor, 0)] },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: SOCIAL_FEED_SIZE + 1,
      select: socialPostSelect,
    }),
    prisma.socialRepost.findMany({
      where: { AND: [socialRepostWhere, { userId: profileId }, afterCursorWhere(cursor, 1)] },
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: SOCIAL_FEED_SIZE + 1,
      select: socialRepostSelect,
    }),
  ]);
  const items: SocialFeedItem[] = [
    ...rows.map((row): SocialFeedItem => ({ kind: "post", createdAtMs: row.createdAt.getTime(), post: toSocialSummary(row) })),
    ...repostRows.map(toRepostItem),
  ];
  return toFeedPage(items);
}

/**
 * The person's pinned post (SOCIAL_TODO B6), for the top of the profile's Posts tab. It is the post only if it may be shown
 * (same rules as the feeds: visible, not deleted, author's account shown) and is really the person's own post; otherwise null
 * (the pin row stays and the post comes back when it is restored).
 */
export async function getSocialPinnedPost(profileId: string): Promise<SocialFeedItem | null> {
  const pin = await prisma.socialPinnedPost.findUnique({
    where: { userId: profileId },
    select: { socialPostId: true, createdAt: true },
  });
  if (!pin) return null;
  const row = await prisma.socialPost.findFirst({
    where: { AND: [socialFeedWhere, { id: pin.socialPostId, authorId: profileId }] },
    select: socialPostSelect,
  });
  return row ? { kind: "post", createdAtMs: row.createdAt.getTime(), post: toSocialSummary(row) } : null;
}

export type SocialProfileReply = { id: number; body: string; time: string; postId: number; postAuthor: string };

/** The Replies tab: the person's visible replies, newest first, only under posts that may be shown. */
export async function getSocialProfileReplies(profileId: string): Promise<SocialProfileReply[]> {
  const rows = await prisma.socialReply.findMany({
    where: { authorId: profileId, status: ContentStatus.VISIBLE, deletedAt: null, socialPost: socialFeedWhere },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: socialProfileListSize,
    select: {
      id: true,
      body: true,
      createdAt: true,
      socialPost: { select: { id: true, author: { select: { username: true } } } },
    },
  });
  return rows.map((row) => ({
    id: row.id,
    body: row.body,
    time: timeAgo(row.createdAt),
    postId: row.socialPost.id,
    postAuthor: row.socialPost.author.username,
  }));
}

/**
 * The Likes tab: the Social posts the person liked, the most recently liked first. The PAGE shows it only to the person
 * themselves (decision: nobody else can see which posts you liked); this function does not check who is asking.
 */
export async function getSocialProfileLikes(profileId: string): Promise<SocialFeedItem[]> {
  const rows = await prisma.socialPostLike.findMany({
    where: { userId: profileId, socialPost: socialFeedWhere },
    orderBy: [{ createdAt: "desc" }, { socialPostId: "desc" }],
    take: socialProfileListSize,
    select: { createdAt: true, socialPost: { select: socialPostSelect } },
  });
  return rows.map((row): SocialFeedItem => ({ kind: "post", createdAtMs: row.createdAt.getTime(), post: toSocialSummary(row.socialPost) }));
}

export type SocialPerson = { username: string; displayName: string | null };

/** The Followers / Following tab: accounts that may be shown, the most recent follow first. */
export async function getSocialProfilePeople(profileId: string, kind: "followers" | "following"): Promise<SocialPerson[]> {
  if (kind === "followers") {
    const rows = await prisma.follow.findMany({
      where: { followingId: profileId, follower: socialAuthorShown },
      orderBy: [{ createdAt: "desc" }, { followerId: "desc" }],
      take: socialProfileListSize,
      select: { follower: { select: { username: true, displayName: true } } },
    });
    return rows.map((row) => row.follower);
  }
  const rows = await prisma.follow.findMany({
    where: { followerId: profileId, following: socialAuthorShown },
    orderBy: [{ createdAt: "desc" }, { followingId: "desc" }],
    take: socialProfileListSize,
    select: { following: { select: { username: true, displayName: true } } },
  });
  return rows.map((row) => row.following);
}

// ---- Hashtag feed (SOCIAL_TODO 6, patch-social-tags). Same visibility rules as the feeds. ONLY for logged-in people
// (PROJECT.md 8j point 11). Not cached: it is read per request, inside the page.

/** The Social posts that use one hashtag (`tag` in its saved form), newest first, paged like the feeds. Posts only: reposts are not listed. */
export async function getSocialTagFeed(tag: string, before: string | null = null): Promise<SocialFeedPage> {
  const cursor = parseCursor(before);
  const rows = await prisma.socialPost.findMany({
    where: { AND: [socialFeedWhere, { tags: { some: { tag } } }, afterCursorWhere(cursor, 0)] },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: SOCIAL_FEED_SIZE + 1,
    select: socialPostSelect,
  });
  const items: SocialFeedItem[] = rows.map((row): SocialFeedItem => ({
    kind: "post",
    createdAtMs: row.createdAt.getTime(),
    post: toSocialSummary(row),
  }));
  return toFeedPage(items);
}

// ---- Social search (SOCIAL_TODO B1, patch-social-search). Same visibility rules as the feeds (socialFeedWhere,
// socialAuthorShown). ONLY for logged-in people (PROJECT.md 8j point 11). Not cached: the text is whatever a person types.
// The text is cleaned first by parseSocialSearch (src/lib/social-search.ts). Block and Mute are applied by the PAGE after
// these reads, for the viewer only. Plain text match (SQLite LIKE: upper / lower case is ignored for A-Z only).

/** Social posts that contain ALL the words, newest first, paged like the feeds. Posts only: reposts are not searched. */
export async function searchSocialPosts(words: string[], before: string | null = null): Promise<SocialFeedPage> {
  const cursor = parseCursor(before);
  const rows = await prisma.socialPost.findMany({
    where: { AND: [socialFeedWhere, ...words.map((word) => ({ body: { contains: word } })), afterCursorWhere(cursor, 0)] },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }],
    take: SOCIAL_FEED_SIZE + 1,
    select: socialPostSelect,
  });
  const items: SocialFeedItem[] = rows.map((row): SocialFeedItem => ({
    kind: "post",
    createdAtMs: row.createdAt.getTime(),
    post: toSocialSummary(row),
  }));
  return toFeedPage(items);
}

/**
 * Accounts that may be shown (socialAuthorShown) whose username or display name contains `term` (lower case, no @).
 * Best match first (exact, starts with, rest; then by username), at most SOCIAL_SEARCH_LIST_SIZE. `blocked` = the people
 * the viewer blocked or who blocked the viewer: they never appear (a muted person still does).
 */
export async function searchSocialPeople(term: string, blocked: ReadonlySet<string>): Promise<SocialPerson[]> {
  const select = { username: true, displayName: true } as const;
  const [starts, contains] = await Promise.all([
    prisma.user.findMany({
      where: { AND: [socialAuthorShown, { username: { startsWith: term } }] },
      orderBy: { username: "asc" },
      take: 60,
      select,
    }),
    prisma.user.findMany({
      where: { AND: [socialAuthorShown, { OR: [{ username: { contains: term } }, { displayName: { contains: term } }] }] },
      orderBy: { username: "asc" },
      take: 120,
      select,
    }),
  ]);
  const visible = [...starts, ...contains].filter((person) => !blocked.has(person.username));
  return rankPeople(visible, term);
}

/**
 * Hashtags (saved form, no `#`) that contain `term` and are used by at least one Social post that may be shown. The exact
 * hashtag first, then the most recently used first (NOT the most used: the fair-ranking rule). No post counts are shown,
 * because a count would include posts of blocked people.
 */
export async function searchSocialTags(term: string): Promise<string[]> {
  const shown = { socialPost: socialFeedWhere };
  const [exact, rows] = await Promise.all([
    prisma.socialPostTag.findFirst({ where: { tag: term, ...shown }, select: { tag: true } }),
    prisma.socialPostTag.groupBy({
      by: ["tag"],
      where: { tag: { contains: term }, ...shown },
      _max: { createdAt: true },
      orderBy: { _max: { createdAt: "desc" } },
      take: SOCIAL_SEARCH_LIST_SIZE,
    }),
  ]);
  return rankTags([...(exact ? [exact.tag] : []), ...rows.map((row) => row.tag)], term);
}

// ---- "n new posts" banner (SOCIAL_TODO B4, patch-social-newposts). How many Social posts and reposts are NEWER than
// `sinceMs`, with the same visibility rules as the feeds. NOT the viewer's own items; not the people in `hidden` (Block
// and Mute: usernames, see loadHiddenAuthors); on "following" only the people the viewer follows. At most NEW_POSTS_CAP are
// counted. Not cached: it belongs to one viewer and the shared caches hold no personal data. Logged-in people only.
export async function countNewSocialItems(
  viewerId: string,
  kind: "all" | "following",
  sinceMs: number,
  hidden: ReadonlySet<string>,
): Promise<number> {
  const since = new Date(sinceMs);
  const hiddenNames = [...hidden];

  let authors: { in: string[] } | { not: string }; // fits both `authorId` (posts) and `userId` (reposts)
  if (kind === "following") {
    const followed = await prisma.follow.findMany({ where: { followerId: viewerId }, select: { followingId: true }, take: MAX_FOLLOWING_IDS });
    // the viewer's own items never count, so the viewer is taken out of the list that `followingAuthorIds` builds
    authors = { in: followingAuthorIds(viewerId, followed.map((row) => row.followingId)).filter((id) => id !== viewerId) };
  } else {
    authors = { not: viewerId };
  }

  const [posts, reposts] = await Promise.all([
    prisma.socialPost.count({
      where: {
        AND: [
          socialFeedWhere,
          { createdAt: { gt: since } },
          { authorId: authors },
          { author: { username: { notIn: hiddenNames } } },
        ],
      },
      take: NEW_POSTS_CAP,
    }),
    prisma.socialRepost.count({
      where: {
        AND: [
          socialRepostWhere,
          { createdAt: { gt: since } },
          { userId: authors },
          { user: { username: { notIn: hiddenNames } } },
          { socialPost: { author: { username: { notIn: hiddenNames } } } },
        ],
      },
      take: NEW_POSTS_CAP,
    }),
  ]);
  return Math.min(posts + reposts, NEW_POSTS_CAP);
}

/**
 * The Bookmarks page (/social/bookmarks, SOCIAL_TODO B2): the Social posts THIS person saved, the most recently SAVED first.
 * Same visibility rules as every feed (`socialFeedWhere`: visible, not deleted, author's account shown), so a hidden or deleted
 * post drops out of the list and comes back with the post. NOT cached on purpose: the list is private and belongs to one viewer.
 * `before` is the cursor of social-bookmark-rules.ts. The page applies Block afterwards (the same as the feeds).
 */
export async function getSocialBookmarks(
  viewerId: string,
  before: string | null = null,
): Promise<{ items: SocialFeedItem[]; next: string | null }> {
  const cursor = parseBookmarkCursor(before);
  const rows = await prisma.socialPostBookmark.findMany({
    where: { AND: [{ userId: viewerId, socialPost: socialFeedWhere }, bookmarkAfterWhere(cursor)] },
    orderBy: [{ createdAt: "desc" }, { socialPostId: "desc" }],
    take: SOCIAL_FEED_SIZE + 1,
    select: { createdAt: true, socialPostId: true, socialPost: { select: socialPostSelect } },
  });
  const keyed = rows.map((row) => ({ row, savedAtMs: row.createdAt.getTime(), id: row.socialPostId }));
  const { items, next } = cutBookmarkPage(keyed, SOCIAL_FEED_SIZE);
  return {
    items: items.map(({ row, savedAtMs }): SocialFeedItem => ({ kind: "post", createdAtMs: savedAtMs, post: toSocialSummary(row.socialPost) })),
    next: next ? bookmarkCursorToText(next) : null,
  };
}
