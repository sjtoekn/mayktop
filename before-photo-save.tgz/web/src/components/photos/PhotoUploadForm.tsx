"use client";

// The upload form of /photos/upload (PHOTO_TODO 4). Quick checks here only save the person a wasted upload; the server
// action (uploadPhoto) checks everything again. After a successful upload the form shows the small version of the photo
// and "Upload another photo" (the photo pages come in PHOTO_TODO 5 and 6).
import { useRef, useState, useTransition } from "react";
import Link from "next/link";
import LoginNotice from "@/components/LoginNotice";
import { useLoggedOut } from "@/lib/use-logged-out";
import { photoThumbUrl } from "@/lib/photo-file";
import { uploadPhoto } from "@/app/(site)/photos/upload/actions";

export type PhotoUploadFormText = {
  title: string;
  choose: string;
  change: string;
  help: string;
  typeError: string;
  sizeError: string;
  pixelsError: string;
  noImage: string;
  preview: string;
  titleLabel: string;
  titleHelp: string;
  captionLabel: string;
  captionPlaceholder: string;
  categoryLabel: string;
  categoryPlaceholder: string;
  categoryRequired: string;
  tagsLabel: string;
  tagsHelp: string;
  rules: string;
  submit: string;
  saving: string;
  cancel: string;
  error: string;
  titleRequired: string;
  invalid: string;
  tagsInvalid: string;
  tooMany: string; // contains {minutes}
  done: string;
  another: string;
  login: string;
  loginLink: string;
};

type Failure = false | "error" | "login" | "title" | "invalid" | "category" | "tags" | "noImage" | "tooMany" | "imageType" | "imageSize" | "imagePixels";

export default function PhotoUploadForm({
  text,
  imageMaxBytes,
  imageTypes,
  titleMax,
  captionMax,
  categories,
}: {
  text: PhotoUploadFormText;
  /** The size limit, in bytes (the server checks it again). */
  imageMaxBytes: number;
  /** The types the file chooser offers (the server checks the real content again). */
  imageTypes: string[];
  titleMax: number;
  captionMax: number;
  /** The categories to choose from: the stored key and the visible name. */
  categories: { value: string; label: string }[];
}) {
  const [title, setTitle] = useState("");
  const [caption, setCaption] = useState("");
  const [category, setCategory] = useState("");
  const [tags, setTags] = useState("");
  const [image, setImage] = useState<{ file: File; preview: string } | null>(null);
  const [failed, setFailed] = useState<Failure>(false);
  const [waitMinutes, setWaitMinutes] = useState(1);
  const [done, setDone] = useState<{ file: string } | null>(null);
  const [pending, startTransition] = useTransition();
  const loggedOut = useLoggedOut();
  const fileInput = useRef<HTMLInputElement>(null);
  const previewUrl = useRef<string | null>(null); // released when it is replaced or removed

  const canSend = !pending && !loggedOut && image !== null && title.trim().length > 0 && category !== "";

  function clearImage() {
    if (previewUrl.current) URL.revokeObjectURL(previewUrl.current);
    previewUrl.current = null;
    setImage(null);
    if (fileInput.current) fileInput.current.value = "";
  }

  function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!imageTypes.includes(file.type)) {
      clearImage();
      setFailed("imageType");
      return;
    }
    if (file.size > imageMaxBytes) {
      clearImage();
      setFailed("imageSize");
      return;
    }
    setFailed(false);
    if (previewUrl.current) URL.revokeObjectURL(previewUrl.current);
    previewUrl.current = URL.createObjectURL(file);
    setImage({ file, preview: previewUrl.current });
  }

  function reset() {
    clearImage();
    setTitle("");
    setCaption("");
    setCategory("");
    setTags("");
    setFailed(false);
    setDone(null);
  }

  function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSend || !image) return;
    setFailed(false);
    startTransition(async () => {
      const form = new FormData();
      form.set("title", title);
      form.set("caption", caption);
      form.set("category", category);
      form.set("tags", tags);
      form.set("image", image.file);
      const result = await uploadPhoto(form);
      if (result.ok) {
        clearImage();
        setDone({ file: result.file });
        return;
      }
      if (result.reason === "tooMany") setWaitMinutes(result.waitMinutes ?? 1);
      setFailed(result.reason);
    });
  }

  if (done) {
    return (
      <div className="sf-wrap">
        <section className="card sf-card">
          <h1 className="sf-h1">{text.title}</h1>
          <div className="notice" role="status">
            {text.done}
          </div>
          <div className="sp-media">
            {/* eslint-disable-next-line @next/next/no-img-element -- the small copy we just stored, served by our own media route */}
            <img src={photoThumbUrl(done.file)} alt={title || text.preview} />
          </div>
          <div className="sf-actions">
            <button type="button" className="btn btn-primary btn-lg" onClick={reset}>
              {text.another}
            </button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="sf-wrap">
      <section className="card sf-card">
        <h1 className="sf-h1">{text.title}</h1>

        {loggedOut && (
          <div className="notice notice-danger" role="status">
            <LoginNotice text={{ message: text.login, link: text.loginLink }} />
          </div>
        )}

        <div className="sf-image">
          <input
            ref={fileInput}
            id="photo-image"
            type="file"
            accept={imageTypes.join(",")}
            hidden
            disabled={loggedOut || pending}
            onChange={onPick}
          />
          <div className="sf-imageRow">
            <button type="button" className="btn btn-secondary" disabled={loggedOut || pending} onClick={() => fileInput.current?.click()}>
              🖼️ {image ? text.change : text.choose}
            </button>
          </div>
          <p className="sf-imageHelp">{text.help}</p>
          {image && (
            <div className="sp-media">
              {/* eslint-disable-next-line @next/next/no-img-element -- a local preview of the chosen file (blob address) */}
              <img src={image.preview} alt={text.preview} />
            </div>
          )}
        </div>

        <label className="sf-label" htmlFor="photo-title">
          {text.titleLabel}
        </label>
        <input
          id="photo-title"
          type="text"
          className="pc-field"
          maxLength={titleMax}
          value={title}
          disabled={loggedOut || pending}
          onChange={(e) => setTitle(e.target.value)}
        />
        <p className="sf-imageHelp">{text.titleHelp}</p>

        <label className="sf-label" htmlFor="photo-caption">
          {text.captionLabel}
        </label>
        <textarea
          id="photo-caption"
          className="pc-field"
          rows={4}
          maxLength={captionMax}
          value={caption}
          disabled={loggedOut || pending}
          placeholder={text.captionPlaceholder}
          onChange={(e) => setCaption(e.target.value)}
        />
        <div className="sp-counter">
          {caption.length}/{captionMax}
        </div>

        <label className="sf-label" htmlFor="photo-category">
          {text.categoryLabel}
        </label>
        <select
          id="photo-category"
          className="pc-field"
          value={category}
          disabled={loggedOut || pending}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">{text.categoryPlaceholder}</option>
          {categories.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>

        <label className="sf-label" htmlFor="photo-tags">
          {text.tagsLabel}
        </label>
        <input
          id="photo-tags"
          type="text"
          className="pc-field"
          maxLength={500}
          value={tags}
          disabled={loggedOut || pending}
          onChange={(e) => setTags(e.target.value)}
        />
        <p className="sf-imageHelp">{text.tagsHelp}</p>

        <p className="sf-imageHelp">{text.rules}</p>

        {failed && (
          <div className="notice notice-danger" role="alert">
            {failed === "login" ? (
              <LoginNotice text={{ message: text.login, link: text.loginLink }} />
            ) : failed === "tooMany" ? (
              text.tooMany.replace("{minutes}", String(waitMinutes))
            ) : failed === "imageType" ? (
              text.typeError
            ) : failed === "imageSize" ? (
              text.sizeError
            ) : failed === "imagePixels" ? (
              text.pixelsError
            ) : failed === "noImage" ? (
              text.noImage
            ) : failed === "title" ? (
              text.titleRequired
            ) : failed === "category" ? (
              text.categoryRequired
            ) : failed === "tags" ? (
              text.tagsInvalid
            ) : failed === "invalid" ? (
              text.invalid
            ) : (
              text.error
            )}
          </div>
        )}

        <div className="sf-actions">
          <Link href="/" className="btn btn-secondary btn-lg">
            {text.cancel}
          </Link>
          <button type="submit" className="btn btn-primary btn-lg" disabled={!canSend}>
            {pending ? text.saving : text.submit}
          </button>
        </div>
      </section>
    </form>
  );
}
