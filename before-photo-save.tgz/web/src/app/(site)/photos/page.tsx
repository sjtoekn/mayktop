import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { connection } from "next/server";
import { t } from "@/i18n";
import { loadPhotoPage } from "@/lib/photo-feed";
import { PHOTO_ROW_HEIGHT, parsePhotoBefore, photoTileStyle } from "@/lib/photo-feed-rules";
import { photoThumbUrl } from "@/lib/photo-file";
import "./photos.css";

export const metadata: Metadata = {
  title: t("photo.list.title"),
};

// /photos (PHOTO_TODO 5): the newest photos, in rows filled to the full width. Anybody (also a visitor) may look; a login is
// needed only to upload (decided 2026-11-08). The page reads the database, so it runs per request: connection() and the
// data sit INSIDE <Suspense>, the same way the Social feed does it (Next.js 16 "instant" check).
// "Load more" opens the next (older) page with ?before=<id of the last photo>; anything that is not a cursor means the first page.
// Not yet here: Block / Mute of authors, category filter (PHOTO_TODO 9), fair ranking (15), the ad tile (16).
type Search = Promise<{ before?: string | string[] }>;

export default function PhotosPage({ searchParams }: { searchParams: Search }) {
  return (
    <Suspense fallback={<p className="pc-empty">…</p>}>
      <PhotosContent searchParams={searchParams} />
    </Suspense>
  );
}

async function PhotosContent({ searchParams }: { searchParams: Search }) {
  await connection();
  const { before } = await searchParams;
  const cursor = parsePhotoBefore(before);
  const page = await loadPhotoPage(cursor);
  const fallbackAlt = t("photo.list.photoAlt");

  return (
    <>
      <header className="card pg-head ph-head">
        <div>
          <h1 className="sf-h1">{t("photo.list.title")}</h1>
          <p className="pc-text">{t("photo.list.sub")}</p>
        </div>
        <Link href="/photos/upload" className="btn btn-primary">
          {t("photo.list.upload")}
        </Link>
      </header>

      {page.items.length === 0 ? (
        <section className="card pg-empty">
          <p>{t("photo.list.empty")}</p>
        </section>
      ) : (
        <>
          <ul className="ph-grid">
            {page.items.map((photo) => {
              const tile = photoTileStyle(photo.width, photo.height, PHOTO_ROW_HEIGHT);
              return (
                <li key={photo.id} className="ph-tile" style={{ flexGrow: tile.grow, flexBasis: tile.basis }}>
                  <Link href={`/photos/${photo.id}`} prefetch={false} style={{ paddingBottom: `${tile.ratioPercent}%` }}>
                    {/* eslint-disable-next-line @next/next/no-img-element -- the small copy from our own media route */}
                    <img src={photoThumbUrl(photo.file)} alt={photo.title || fallbackAlt} width={photo.width} height={photo.height} loading="lazy" decoding="async" />
                  </Link>
                </li>
              );
            })}
          </ul>

          <nav className="ph-more">
            {cursor !== null ? (
              <Link href="/photos" className="btn btn-secondary">
                {t("photo.list.newest")}
              </Link>
            ) : null}
            {page.next !== null ? (
              <Link href={`/photos?before=${page.next}`} className="btn btn-secondary">
                {t("photo.list.more")}
              </Link>
            ) : null}
          </nav>
        </>
      )}
    </>
  );
}
